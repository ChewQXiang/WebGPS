/**
 * 
 */
/**
 * 
 */
module GPSLocationSystem {
	requires jdk.httpserver; // 聲明此模組需要用到 JDK 內建的 HTTP Server 模組
}